//Roger Souza Brandao - 20250108154
#include <stdio.h>
#include <stdlib.h>

int primo(int n) {
    if (n < 2) return 0;
    if (n == 2) return 1;
    if (n % 2 == 0) return 0;
    
    //divisibilidade ate a raiz quadrada de n
    for (int i = 3; i * i <= n; i += 2) {
        if (n % i == 0) return 0;
    }
    return 1;
}

int main() {
    FILE *entrada, *saida;
    int numero;
    
    //bre arquivo de entrada
    entrada = fopen("numeros.txt", "r");
    if (entrada == NULL) {
        printf("Erro ao abrir arquivo de entrada\n");
        return 1;
    }
    
    //abre arquivo de saida
    saida = fopen("resultado_primos.txt", "w");
    if (saida == NULL) {
        printf("erro ao criar arquivo de saida\n");
        fclose(entrada);
        return 1;
    }
    
    //le numeros e se sao primos
    while (fscanf(entrada, "%d", &numero) == 1) {
        if (primo(numero)) {
            fprintf(saida, "%d eh primo\n", numero);
        } else {
            fprintf(saida, "%d nao eh primo\n", numero);
        }
    }
    
    fclose(entrada);
    fclose(saida);
    
    printf("resultado em 'resultado_primos.txt'\n");
    
    return 0;
}